const ggSdk = require('aws-greengrass-core-sdk');

const iotClient = new ggSdk.IotData();
const os = require('os');
const util = require('util');

function publishCallback(err, data) {
    console.log(err);
    console.log(data);
}

var mqtt = require('mqtt');
var fs = require('fs');

//QIoT MQTT settings. Copy the details from resourceinfo.json
var PORT = 21883;
var HOST = '172.17.28.52';
var options = {
  clean: true, // set to false to receive QoS 1 and 2 messages while offline
  clientId: 'my-device1'+Math.floor(Math.random()*100+1),
  protocol: 'mqtt',
  port: PORT,
  host: HOST,
  username:"8e22e1a2-a863-475a-ac17-e8639237d661",
  password:"r:f39313f65700dc5a7decf288023c1722",
  rejectUnauthorized : false, 
};

var client = mqtt.connect(options);

exports.handler = function handler(event, context) {
      // Topic name to subscribe
      client.subscribe('qiot/things/admin/AWSgreengrass/resolve');
      client.on('message', function(topic, message,packet) {
        var originaldata = new Buffer(message, 'base64');
        //console.log(originaldata);
        message=originaldata.toString('utf8');
        // AWS GG topic & Message
        const pubOpt = {
          topic: 'predictedImage',
          payload: JSON.stringify(message),
        };
        iotClient.publish(pubOpt, publishCallback);
      });
      client.on('connect', function(){
      	console.log('Connected');
      });
      client.on('close', function(err){
      	console.log('close'+err);
      });
      client.on('reconnect', function(){
      	console.log('reconnect');
      });
      client.on('error', function(error){
      	console.log(error);
      });
      console.log('Initiate Connection');
    console.log(event);
    console.log(context);
};


exports.handler();

