var AWS = require('aws-sdk'),
    fs = require('fs');
exports.handler = (event, context, callback) => {
    AWS.config.update({ accessKeyId: 'XXXXXXXXX', secretAccessKey: 'XXXXXXXXXXXXXXXXXXXX' });
    var data='data:image/png;base64,'+event.image;
    var s3 = new AWS.S3();
    var datetime=getDateTime();
    var data = data.replace(/^data:image\/\w+;base64,/, "");
    var buf = new Buffer(data, 'base64');
    fs.writeFile('/tmp/image.png', buf);
      //console.log(s3);
      fs.readFile('/tmp/image.png', function (err, data) {
  		if (err) { throw err; }
	      s3.putObject({
	        Bucket: 'qiotquaiggdemo',
	        Key: datetime+'.png',
	        Body: data ,
	        ACL: 'public-read',
	        //ContentEncoding: 'base64',
	        ContentType: 'image/png'
	      },function (resp) {
	        console.log(arguments);
	        console.log('Successfully uploaded package.');
	      });
	  });
    
   // });
    // TODO implement
    //callback(null, 'Hello from Lambda');
};

function getDateTime() {
    var now     = new Date(); 
    var year    = now.getFullYear();
    var month   = now.getMonth()+1; 
    var day     = now.getDate();
    var hour    = now.getHours();
    var minute  = now.getMinutes();
    var second  = now.getSeconds(); 
    if(month.toString().length == 1) {
        var month = '0'+month;
    }
    if(day.toString().length == 1) {
        var day = '0'+day;
    }   
    if(hour.toString().length == 1) {
        var hour = '0'+hour;
    }
    if(minute.toString().length == 1) {
        var minute = '0'+minute;
    }
    if(second.toString().length == 1) {
        var second = '0'+second;
    }   
    var dateTime = year+'/'+month+'/'+day+'/'+hour+':'+minute+':'+second;   
     return dateTime;
}
