var http = require('http');

exports.handler = function handler(event, context) {
      const options = {
        hostname: '172.17.28.52',
        port: 23000,
        path: '/resources/qiot/things/admin/cameraPi/image',
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'requesterid': '44cfdf27-32d6-4add-8ad9-31832d3b6ba8',
          'Access-Token': 'r:2cbcc4fb16e7f7c34c160c97d41b9719'
        }
      };
    
      const req = http.request(options, (res) => {
        console.log(`STATUS: ${res.statusCode}`);
        console.log(`HEADERS: ${JSON.stringify(res.headers)}`);
        res.setEncoding('utf8');
        res.on('data', (chunk) => {
          console.log(`BODY: ${chunk}`);
        });
        res.on('end', () => {
          console.log('No more data in response.');
        });
      });
      
      req.on('error', (e) => {
        console.error(`problem with request: ${e.message}`);
      });
      
      // write data to request body
      req.write(JSON.stringify(event.value));
      //req.write(event.value);
      req.end();
      console.log(event);
      console.log(context);
};



